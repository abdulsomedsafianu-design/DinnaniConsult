# Free-tier Cloudflare deployment guide

## What is free and what is not

Cloudflare Workers has a free tier and supplies a `*.workers.dev` subdomain, subject to usage and resource limits. No custom `.com` registration is included. Supabase has a separate free tier with storage, database and bandwidth limits. Cloudflare account ownership, Supabase account ownership and deployment are manual steps.

This is a **Cloudflare Workers/OpenNext** deployment, not a static Cloudflare Pages export: the Next.js server actions, authentication, and signed download routes require a server runtime. Cloudflare Pages static hosting alone is insufficient.

## 1. Prepare Supabase

1. Create a Supabase project, record Project URL and publishable/anon key.
2. Execute `supabase/schema.sql` in the SQL editor.
3. Create your own admin user under Authentication > Users, and run `insert into public.admin_users(user_id) values ('YOUR_USER_UUID');`.
4. Keep public sign-up disabled for the admin workflow. Do not expose the service-role key to the browser.

## 2. Install and configure

```bash
npm install
cp .env.example .env.local
```

Fill the public Supabase URL/key in `.env.local` for build-time use. Do **not** commit `.env.local`. The site URL can initially use your eventual `https://<worker>.<account>.workers.dev` URL; after first deploy, set it to the actual deployed URL and redeploy.

## 3. Configure Cloudflare secrets and build-time variables

Authenticate with `npx wrangler login` and confirm your account with `npx wrangler whoami`.

Public `NEXT_PUBLIC_*` variables are **compiled into Next.js client bundles at build time**. Set `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and `NEXT_PUBLIC_SITE_URL` in your local `.env.local` and in CI build environment. The `SUPABASE_SERVICE_ROLE_KEY` must be set as a **Worker secret** using:

```bash
npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY
```

Also set the public variables as Worker runtime vars/secrets for server-side requests, for example:

```bash
npx wrangler secret put NEXT_PUBLIC_SUPABASE_URL
npx wrangler secret put NEXT_PUBLIC_SUPABASE_ANON_KEY
npx wrangler secret put NEXT_PUBLIC_SITE_URL
```

Note: Wrangler secrets must exist on the deployed Worker. Depending on your deployment workflow, first deploy a placeholder Worker before adding secrets, then redeploy the application. Never commit real keys or put service-role credentials in `NEXT_PUBLIC_*` variables.

## 4. Deploy

```bash
npm run typecheck
npm run cf:build
npm run deploy
```

Cloudflare should return a `workers.dev` URL after a successful deployment. Enable the workers.dev route in your Worker settings if it is disabled. Set Supabase Auth Site URL and allowed redirect URLs to the real HTTPS address. Rebuild if `NEXT_PUBLIC_SITE_URL` changes.

## 5. Verify before sharing publicly

- Home, About, Experience, Projects, Resources pages render on desktop and mobile.
- Published files are searchable and downloadable without sign-in.
- Admin sign-in works; a non-admin user is rejected.
- Upload a test PDF and PPTX, publish, unpublish and delete them.
- Anonymous requests cannot retrieve unpublished files, use admin actions or enumerate private storage objects.
- Verify response headers, cookie sessions, logout and file size/type enforcement.
- Monitor Worker requests and Supabase storage/bandwidth quotas; free plans are not unlimited.

## Deployment and security caveats

- No deployment, domain registration, cloud account creation or external configuration has been performed by this project archive.
- The 20 MB upload limit may exceed effective Worker request/memory limits on a free plan. Test with small files first; for larger files, implement browser-to-Supabase signed upload URLs rather than proxying uploads through Worker server actions.
- The current starter performs extension and MIME checks but does **not** malware-scan uploads. Add scanning, stricter file-signature checks and audit logs before scaling.
- `@opennextjs/cloudflare` and Next.js evolve rapidly; test adapter compatibility and the latest provider documentation if installation/build fails.
- Cloudflare Workers free limits and Supabase free quotas may change; confirm current limits before public launch.
