# Dinnani Consultancy — Cloudflare Workers Edition

Professional cybersecurity / IT audit portfolio and public teaching-resource hub.

**Deployment target:** Cloudflare Workers via OpenNext, with a free `workers.dev` subdomain. **Backend:** Supabase Auth, Postgres and private Storage. The preferred `DinnaniConsultancy.com` is **not registered**.

See [CLOUDFLARE_DEPLOYMENT.md](CLOUDFLARE_DEPLOYMENT.md) for setup, secrets, free-tier limits, deployment, and security tests. The project has not been deployed or end-to-end tested against a real Supabase account.
