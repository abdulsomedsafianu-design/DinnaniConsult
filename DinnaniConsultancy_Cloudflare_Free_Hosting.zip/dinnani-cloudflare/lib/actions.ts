'use server';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { privilegedDb, requireAdmin, sessionDb } from './supabase';
const MAX_BYTES=20*1024*1024;
const ALLOWED = new Map([
  ['application/pdf','.pdf'],
  ['application/vnd.openxmlformats-officedocument.wordprocessingml.document','.docx'],
  ['application/vnd.openxmlformats-officedocument.presentationml.presentation','.pptx'],
  ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','.xlsx']
]);
export type ActionState={error?:string;success?:string};
function field(form:FormData,key:string,max=180) { const value=form.get(key); return typeof value==='string' ? value.trim().slice(0,max) : ''; }
export async function login(_prev:ActionState, form:FormData):Promise<ActionState> {
  const email=field(form,'email',254), password=field(form,'password',500);
  if(!email || !password) return {error:'Enter your email and password.'};
  try {
    const db=await sessionDb();
    const {error}=await db.auth.signInWithPassword({email,password});
    if(error) return {error:'Invalid credentials.'};
    const admin=await requireAdmin();
    if(!admin){ await db.auth.signOut(); return {error:'This account does not have administrator access.'}; }
  } catch { return {error:'Authentication is not configured or temporarily unavailable.'}; }
  redirect('/admin');
}
export async function logout(){const db=await sessionDb(); await db.auth.signOut(); redirect('/admin/login');}
export async function uploadResource(_prev:ActionState,form:FormData):Promise<ActionState> {
  const admin=await requireAdmin(); if(!admin) return {error:'Administrator authorization required.'};
  const title=field(form,'title',160), description=field(form,'description',1000), category=field(form,'category',60), audience=field(form,'audience',80);
  const file=form.get('file');
  if(!title || !category || !audience || !(file instanceof File)) return {error:'Title, category, audience and file are required.'};
  if(!['Lecture Notes','Presentations','Worksheets','Study Guides','Research'].includes(category)) return {error:'Invalid category.'};
  if(file.size===0 || file.size>MAX_BYTES) return {error:'Files must be between 1 byte and 20 MB.'};
  const extension=ALLOWED.get(file.type);
  if(!extension || !file.name.toLowerCase().endsWith(extension)) return {error:'Only PDF, DOCX, PPTX and XLSX files are supported.'};
  const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,'_').slice(-120);
  const path=`${crypto.randomUUID()}/${safeName}`;
  try {
    const db=privilegedDb();
    const bytes=await file.arrayBuffer();
    const {error:uploadError}=await db.storage.from('learning-resources').upload(path,bytes,{contentType:file.type,upsert:false});
    if(uploadError) return {error:'File storage failed. Check bucket configuration.'};
    const {error:insertError}=await db.from('resources').insert({title,description:description||null,category,audience,filename:file.name,mime_type:file.type,size_bytes:file.size,storage_path:path,published:field(form,'published')==='on',created_by:admin.user.id});
    if(insertError){await db.storage.from('learning-resources').remove([path]);return {error:'Resource record could not be saved.'};}
    revalidatePath('/resources');revalidatePath('/admin');
    return {success:'Resource uploaded successfully.'};
  } catch {return {error:'Upload failed. Verify server configuration and try again.'};}
}
export async function updateResource(form:FormData) {
  const admin=await requireAdmin(); if(!admin) redirect('/admin/login');
  const id=field(form,'id',80), operation=field(form,'operation',20);
  if(!/^[0-9a-f-]{36}$/i.test(id)) return;
  const db=privilegedDb();
  const {data}=await db.from('resources').select('storage_path,published').eq('id',id).maybeSingle();
  if(!data) return;
  if(operation==='toggle') await db.from('resources').update({published:!data.published}).eq('id',id);
  if(operation==='delete') {
    // Remove database record first; if file removal fails, only an orphaned private file remains.
    const {error}=await db.from('resources').delete().eq('id',id);
    if(!error) await db.storage.from('learning-resources').remove([data.storage_path]);
  }
  revalidatePath('/resources');revalidatePath('/admin');
}
