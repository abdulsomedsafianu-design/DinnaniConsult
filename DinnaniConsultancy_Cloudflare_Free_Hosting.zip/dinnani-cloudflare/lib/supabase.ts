import { createClient as createSupabaseClient } from '@supabase/supabase-js';
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';

function publicConfig() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  return { url, key };
}
export function publicDb() {
  const cfg = publicConfig();
  return cfg ? createSupabaseClient(cfg.url, cfg.key, { auth: { persistSession:false, autoRefreshToken:false } }) : null;
}
export function privilegedDb() {
  const cfg = publicConfig();
  const secret = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!cfg || !secret) throw new Error('Supabase server credentials are not configured');
  return createSupabaseClient(cfg.url, secret, { auth:{persistSession:false,autoRefreshToken:false} });
}
export async function sessionDb() {
  const cfg = publicConfig();
  if (!cfg) throw new Error('Supabase public credentials are not configured');
  const store = await cookies();
  return createServerClient(cfg.url, cfg.key, {
    cookies: {
      getAll() { return store.getAll(); },
      setAll(items) { try { items.forEach(({name,value,options}) => store.set(name,value,options)); } catch { /* Server Component read-only context; middleware refreshes cookies */ } }
    }
  });
}
export async function requireAdmin() {
  const client = await sessionDb();
  const {data:{user},error} = await client.auth.getUser();
  if (error || !user) return null;
  const {data} = await client.from('admin_users').select('user_id').eq('user_id',user.id).maybeSingle();
  return data ? {client,user} : null;
}
