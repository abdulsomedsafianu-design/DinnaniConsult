import { publicDb } from './supabase';
export type Resource = {id:string;title:string;description:string|null;category:string;audience:string;filename:string;mime_type:string;size_bytes:number;created_at:string;published:boolean};
export async function publishedResources(): Promise<Resource[]> {
  const client=publicDb();
  if(!client) return [];
  const {data,error}=await client.from('resources').select('id,title,description,category,audience,filename,mime_type,size_bytes,created_at,published').eq('published',true).order('created_at',{ascending:false});
  if(error) throw new Error('Unable to load resources');
  return data as Resource[];
}
