import type {Metadata} from 'next';
import Nav from '@/components/nav';import Footer from '@/components/footer';import './globals.css';
export const metadata:Metadata={title:{default:'Dinnani Consultancy | Cybersecurity, IT Audit & Education',template:'%s | Dinnani Consultancy'},description:'Professional portfolio in cybersecurity, IT audit, technology risk, financial services, and computer science education. Access public learning resources.',metadataBase:new URL(process.env.NEXT_PUBLIC_SITE_URL||'https://DinnaniConsultancy.com')};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><Nav/><main>{children}</main><Footer/></body></html>}
