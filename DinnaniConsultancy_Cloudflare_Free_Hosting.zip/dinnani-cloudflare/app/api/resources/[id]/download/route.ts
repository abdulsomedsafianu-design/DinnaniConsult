import { NextRequest, NextResponse } from 'next/server';
import { privilegedDb } from '@/lib/supabase';
export const dynamic='force-dynamic';
export async function GET(_request:NextRequest,{params}:{params:Promise<{id:string}>}) {
  const {id}=await params;
  if(!/^[0-9a-f-]{36}$/i.test(id)) return new NextResponse('Not found',{status:404});
  try {
    const db=privilegedDb();
    const {data}=await db.from('resources').select('storage_path').eq('id',id).eq('published',true).maybeSingle();
    if(!data) return new NextResponse('Not found',{status:404});
    const {data:signed,error}=await db.storage.from('learning-resources').createSignedUrl(data.storage_path,60);
    if(error || !signed?.signedUrl) return new NextResponse('File unavailable',{status:503});
    return NextResponse.redirect(signed.signedUrl,302);
  } catch {return new NextResponse('File unavailable',{status:503});}
}
