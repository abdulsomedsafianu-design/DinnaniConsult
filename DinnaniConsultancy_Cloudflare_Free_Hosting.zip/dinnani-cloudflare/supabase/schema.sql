-- Execute in Supabase SQL Editor. The bucket is PRIVATE by design.
create extension if not exists pgcrypto;
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade
);
create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 160),
  description text,
  category text not null check (category in ('Lecture Notes','Presentations','Worksheets','Study Guides','Research')),
  audience text not null,
  filename text not null,
  mime_type text not null,
  size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 20971520),
  storage_path text not null unique,
  published boolean not null default false,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;
alter table public.resources enable row level security;
revoke all on public.admin_users from anon;
grant select on public.admin_users to authenticated;
grant select on public.resources to anon,authenticated;
create policy "Admins can check own membership" on public.admin_users for select to authenticated using (user_id = (select auth.uid()));
create policy "Anyone can read published resources" on public.resources for select to anon,authenticated using (published = true or exists (select 1 from public.admin_users a where a.user_id=(select auth.uid())));
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('learning-resources','learning-resources',false,20971520,array[
'application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document',
'application/vnd.openxmlformats-officedocument.presentationml.presentation',
'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'])
on conflict (id) do update set public=false,file_size_limit=20971520,allowed_mime_types=excluded.allowed_mime_types;
-- Resource writes and private storage access are server-only via the service-role key,
-- after the authenticated user is verified against admin_users.
-- Create the administrator in Supabase Authentication (no public signup UI), then run:
-- insert into public.admin_users(user_id) values ('REPLACE_WITH_AUTH_USER_UUID');
